<?php
/**
 * Flatsome functions and definitions
 *
 * @package flatsome
 */
update_option( 'flatsome_wup_purchase_code', 'e2eb9ef2-bc34-8ed2-39b4-ad59974c6f51' );
require get_template_directory() . '/inc/init.php';

/**
 * Note: It's not recommended to add any custom code here. Please use a child theme so that your customizations aren't lost during updates.
 * Learn more here: http://codex.wordpress.org/Child_Themes
 */
