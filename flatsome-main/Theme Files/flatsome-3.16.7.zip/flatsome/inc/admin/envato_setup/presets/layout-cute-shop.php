<?php

return array("preset_home" => 'Cute Shop','type_headings' => array('font-family'=> 'Slabo 27px'), 'type_texts' => array('font-family'=> 'Open Sans'), 'type_nav' => array('font-family'=> 'Montserrat','variant' => 'regular'), "dropdown_border" => "#fff","dropdown_bg" => "#FFF","color_primary" => "#a16695","footer_bottom_align" => "center", "footer_1" => "0","footer_2" => "0", "footer_bottom_text" => "light", "footer_bottom_color" => '#fff');
